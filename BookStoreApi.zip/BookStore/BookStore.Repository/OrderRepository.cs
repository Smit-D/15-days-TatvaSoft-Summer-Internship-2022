﻿using BookStore.Model.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.Repository
{
    public class OrderRepository:BaseRepository
    {
        public Orderdtl AddOrder(Orderdtl orderItem)
        {
            var entry = _context.Orderdtls.Add(orderItem);
            _context.SaveChanges();
            return entry.Entity;
        }
    }
}
