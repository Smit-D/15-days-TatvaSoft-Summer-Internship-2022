﻿using BookStore.Model.Data;
using BookStore.Model.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.Repository
{
    public class CartRepository:BaseRepository
    {
        
        public List<Cart> GetCartItems(string keyword)
        {
            keyword = keyword?.ToLower()?.Trim();
            var query = _context.Carts.Include(c => c.Book).Where(c => keyword == null || c.Book.Name.ToLower().Contains(keyword)).AsQueryable();
            return query.ToList();
        }
        
        public Cart GetCart(int id)
        {
            return _context.Carts.FirstOrDefault(c => c.Id == id);
        }
        public Cart AddCart(Cart cartItem)
        {
            var entry = _context.Carts.Add(cartItem);
            _context.SaveChanges();
            return entry.Entity;
        }
        public Cart UpdateCart(Cart cartItem)
        {

            var entry = _context.Carts.Update(cartItem);
            if (entry != null)
                _context.SaveChanges();
            return entry.Entity;
        }
        /*public int GetQuantityById(int id)
        {
            if (id == 0)
                return 0;
            int qid=_context.Carts.Where(c => c.Id == id).FirstOrDefault().Quantity;
            _context.SaveChanges();
            return qid;
        }*/
        public Cart GetCartItem(int id)
        {
            return _context.Carts.FirstOrDefault(c => c.Id == id);
        }
        public bool DeleteCart(int id)
        {
            var cartItem = _context.Carts.FirstOrDefault(c => c.Id == id);
            if (cartItem == null)
                return false;
            _context.Carts.Remove(cartItem);
            _context.SaveChanges();
            return true;
        }
    }
}
