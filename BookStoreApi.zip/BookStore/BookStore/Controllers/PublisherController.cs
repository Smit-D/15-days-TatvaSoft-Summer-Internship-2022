﻿using BookStore.Model.Data;
using BookStore.Model.Models;
using BookStore.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Net;

namespace BookStore.Controllers
{
    //Delete =>id if it is not present in db then also return HttpDeleteAttribute successsfull in all cases
    //Get by id new filed Books it is not visible in list books
    //Add books of that particular publisher then also showing [empty]
    [ApiController]
    [Route("api/publishers")]
    public class PublisherController : ControllerBase
    {
        PublisherRepository _publisherRepository =new PublisherRepository();
        [HttpGet]
        [Route("list")]
        [ProducesResponseType(typeof(ListResponse<PublisherModel>), (int)HttpStatusCode.OK)]
        public IActionResult GetPublishers(int pageIndex = 1, int pageSize = 10, string keyword = "")
        {
            var publisher = _publisherRepository.GetPublishers(pageIndex, pageSize, keyword);
            ListResponse<PublisherModel> listResponse = new ListResponse<PublisherModel>()
            {
                Results = publisher.Results.Select(c => new PublisherModel(c)),
                TotalRecords = publisher.TotalRecords,
            };
            return Ok(listResponse);
        }
        [HttpGet]
        [Route("{id}")]
        [ProducesResponseType(typeof(PublisherModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(NotFoundResult), (int)HttpStatusCode.NotFound)]
        public IActionResult GetPublisher(int id)
        {
            if(id < 1)
            {
                return NotFound("Invalid Id! Entered Id doesn't exists");
            }
            var publisher = _publisherRepository.GetPublisher(id);
            PublisherModel publisherModel = new PublisherModel(publisher);
            if (publisherModel == null)
                return NotFound("Publisher not found");

            return Ok(publisherModel);
        }
        //Add Publisher
        [HttpPost]
        [Route("add")]
        [ProducesResponseType(typeof(PublisherModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(BadRequestObjectResult), (int)HttpStatusCode.BadRequest)]
        public IActionResult AddPublisher(PublisherModel model)
        {
            if(model == null)
            return BadRequest(model);
            Publisher publish = new Publisher()
            {
                Id = model.Id,
                Name = model.Name,
                Address = model.Address,
                Contact = model.Contact,
            };
            var addedPublisher=_publisherRepository.AddPublisher(publish);
            PublisherModel publisherModel = new PublisherModel(addedPublisher);

            return Ok(publisherModel);
            //return Ok("Publisher added Successfully");
        }

        //Update Publisher Details
        [HttpPut]
        [Route("update")]
        [ProducesResponseType(typeof(PublisherModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(BadRequestObjectResult), (int)HttpStatusCode.BadRequest)]
        public IActionResult UpdatePublisher(PublisherModel model)
        {
            if(model==null)
                return BadRequest("Model can't be empty!");
            Publisher publish = new Publisher()
            {
                Id = model.Id,
                Name = model.Name,
                Address = model.Address,
                Contact = model.Contact,
            };
            var updatedPublisher=_publisherRepository.UpdatePublisher(publish);
            PublisherModel publisherModel = new PublisherModel(updatedPublisher);
            return Ok(publisherModel);
            //return Ok("Details updated Successfully");
        }

        //Delete Publisher 
        [HttpDelete]
        [Route("delete/{id}")]
        [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(BadRequestObjectResult), (int)HttpStatusCode.BadRequest)]
        public IActionResult DeletePublisher(int id)
        {
            if (id < 1)
                return BadRequest("Invalid Id! Please Enter Valid Id");
            _publisherRepository.DeletePublisher(id);
            return StatusCode(HttpStatusCode.OK.GetHashCode(), "Publisher deleted successfully");

        }
    }
}

