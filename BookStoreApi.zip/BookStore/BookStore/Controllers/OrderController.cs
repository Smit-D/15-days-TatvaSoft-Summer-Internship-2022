﻿using BookStore.Model.Models;
using BookStore.Model.Data;
using BookStore.Repository;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    [Route("api/NotOrder")]
    public class OrderController : Controller
    {
        private readonly OrderRepository _orderRepository = new ();
        [HttpPost]
        [Route("Add")]
        public IActionResult AddOrder(OrderModel model)
        {
            if (model == null)
                return BadRequest("Model can't be empty");
            Orderdtl Orderdtl = new ()
            {
                Id = model.Id,
                Quantity = 1,
                Bookid = model.Bookid,
               
            };
            Orderdtl = _orderRepository.AddOrder(Orderdtl);
            OrderModel OrderModel = new (Orderdtl);
            return Ok(OrderModel);
        }
    }
}
