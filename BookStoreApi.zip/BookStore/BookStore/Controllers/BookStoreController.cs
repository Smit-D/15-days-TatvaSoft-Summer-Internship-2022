﻿using BookStore.Model.Data;
using BookStore.Model.Models;
using BookStore.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;

namespace BookStore.Controllers
{
    [Route("api/BookStore")]
    [ApiController]
    public class BookStoreController : ControllerBase
    {
        UserRepository _repository = new UserRepository();
        [HttpPost]
        [Route("Login")]
        public IActionResult Login(LoginModel model)
        {
            try
            {
                User user = _repository.Login(model);
                if (user == null)
                    return NotFound("User not found. Enter valid email and password");

                return Ok(user);
            }
            catch (Exception ex)
            {
                return StatusCode(HttpStatusCode.InternalServerError.GetHashCode(), ex.Message);
            }
        }
        [HttpPost]
        [Route("RegisterUser")]
        public IActionResult Register(RegisterModel model)
        {
            try
            {
                User user = _repository.Register(model);
                if (user == null)
                    return BadRequest("User can't be registered");

                return Ok(user);
            }
            catch (Exception ex)
            {
                return StatusCode(HttpStatusCode.InternalServerError.GetHashCode(), ex.Message);
            }
        }
    }
}
