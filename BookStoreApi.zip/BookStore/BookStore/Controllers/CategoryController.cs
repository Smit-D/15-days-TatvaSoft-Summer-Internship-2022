﻿using BookStore.Model.Data;
using BookStore.Model.Models;
using BookStore.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Net;

namespace BookStore.Controllers
{   
    [Route("api/category")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        CategoryRepository _categoryRepository = new CategoryRepository();
        [HttpGet]
        [Route("list")]
        [ProducesResponseType(typeof(ListResponse<CategoryModel>), (int)HttpStatusCode.OK)]     
        //For front-end developer knowledge about response type of method, ProduceResponsetype is useful

        public IActionResult GetCategories(string keyword ,int pageIndex = 1, int pageSize = 10)
        {
            var categories = _categoryRepository.GetCategories(pageIndex, pageSize, keyword);
            ListResponse<CategoryModel> listResponse = new ListResponse<CategoryModel>()
            {
                Results = categories.Results.Select(c => new CategoryModel(c)),
                TotalRecords = categories.TotalRecords,
        };
            return Ok(listResponse);
        }
        [HttpGet]
        [Route("{id}")]
        [ProducesResponseType(typeof(CategoryModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(NotFoundResult), (int)HttpStatusCode.NotFound)]
        public IActionResult GetCategory(int id)
        {
            if (id < 1)
                return NotFound("Invalid Id! Entered Id doesn't exists");
            var category= _categoryRepository.GetCategory(id);
            if (category == null)
                return NotFound("Book Not found! Check => id");
            CategoryModel cModel = new CategoryModel(category);
            return Ok(cModel);
        }
        [HttpPost]
        [Route("add")]
        [ProducesResponseType(typeof(CategoryModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(BadRequestObjectResult), (int)HttpStatusCode.BadRequest)]

        public IActionResult AddCategory(CategoryModel model)
        {
            if(model == null)
                return BadRequest("Model can't be empty!");
            Category category = new Category()
            {
                Id = model.Id,
                Name = model.Name,
            };
            var addedcategory = _categoryRepository.AddCategory(category);
            CategoryModel categoryModel = new CategoryModel(addedcategory);
            return Ok(categoryModel);
        }
        [HttpPut]
        [Route("update")]
        [ProducesResponseType(typeof(CategoryModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(BadRequestObjectResult), (int)HttpStatusCode.BadRequest)]
        public IActionResult UpdateCategory(CategoryModel model)
        {
            if(model==null)
                return BadRequest("Model can't be empty!");    
            Category category = new Category()
            {
                Id = model.Id,
                Name = model.Name,
            };
            var addedcategory = _categoryRepository.UpdateCategory(category);
            CategoryModel categoryModel = new CategoryModel(addedcategory);
            return Ok(categoryModel);
        }
        [HttpDelete]
        [Route("delete/{id}")]
        [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(BadRequestObjectResult), (int)HttpStatusCode.BadRequest)]
        public IActionResult DeleteCategory(int id)
        {
            if (id < 1)
                return BadRequest("Invalid Id! Please Enter Valid Id");
          
            _categoryRepository.DeleteCategory(id);
            return StatusCode(HttpStatusCode.OK.GetHashCode(), "Category deleted successfully");
        }
    }
}
