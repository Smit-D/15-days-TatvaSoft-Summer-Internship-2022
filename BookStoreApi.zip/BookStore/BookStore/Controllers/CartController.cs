﻿using BookStore.Model.Data;
using BookStore.Model.Models;
using BookStore.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Net;

namespace BookStore.Controllers
{
    [ApiController]
    [Route("api/Cart")]
    public class CartController : ControllerBase
    {
        private readonly CartRepository _cartRepository = new ();
        [HttpGet]
        [Route("list")]
        [ProducesResponseType(typeof(BookModel), (int)HttpStatusCode.OK)]
        public IActionResult GetCartItems(string keyword)//for items present in cart
        {
            List<Cart> carts = _cartRepository.GetCartItems(keyword);
            IEnumerable<CartModel> cartModels = carts.Select(c => new CartModel(c));

            return Ok(cartModels);
        }
       

        [HttpGet]
        [Route("{id}")]
        [ProducesResponseType(typeof(CartModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(NotFoundResult), (int)HttpStatusCode.NotFound)]
        public IActionResult GetCartById(int id)
        {
            if (id < 1)
                return NotFound("Invalid Id! Entered Id doesn't exists");
            var cart = _cartRepository.GetCart(id);
            if (cart == null)
                return NotFound("Cart item Not found! Check => id");
            CartModel cModel = new (cart);
            return Ok(cModel);
        }
        [HttpPost]
        [Route("Add")]
        [ProducesResponseType(typeof(CartModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(BadRequestObjectResult), (int)HttpStatusCode.BadRequest)]
        public IActionResult AddToCart(CartModel model)
        {
            if(model == null)
                return BadRequest("Model can't be empty");
            Cart cart = new ()
            {
                Id = model.Id,
                Quantity = 1,
                Bookid = model.Bookid,
                Userid = model.Userid,
            };
            cart =_cartRepository.AddCart(cart);
            CartModel cartModel = new (cart);
            return Ok(cartModel);
        }
        [HttpPut]
        [Route("Update")]
        [ProducesResponseType(typeof(CartModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(BadRequestObjectResult), (int)HttpStatusCode.BadRequest)]
        public IActionResult UpdateCart(CartModel model)
        {
            if (model == null)
                return BadRequest("Model can't be empty");

            Cart cart = new ()
            {
                Id = model.Id,
                Quantity = model.Id,
                Bookid = model.Bookid,
                Userid = model.Userid,
                
            };
            cart = _cartRepository.UpdateCart(cart);
            //CartModel cartModel = new CartModel(cart);
            return Ok(cart);
        }
        [HttpDelete]
        [Route("Delete/{id}")]
        [ProducesResponseType(typeof(CartModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(BadRequestObjectResult), (int)HttpStatusCode.BadRequest)]
        public IActionResult DeleteCart(int id)
        {
            if (id < 1)
                return BadRequest("Model can't be empty");

            _cartRepository.DeleteCart(id);
            return StatusCode(HttpStatusCode.OK.GetHashCode(), "Cart Item deleted successfully");
        }
    }
}
