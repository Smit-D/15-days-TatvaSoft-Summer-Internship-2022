﻿using BookStore.Model.Data;
using System.Collections.Generic;

namespace BookStore.Model.Models
{
    //For React purpose
    public class ListResponse<T> where T : class//use of generic
        //can access same class in multiple ways for different objects. using this class we will access list of categories, books, etc
    {
        public IEnumerable<T> Results { get; set; }
        public int TotalRecords { get; set; }

    }
}
